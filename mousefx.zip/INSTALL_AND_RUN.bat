@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo          MouseFX Windows Setup
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo Python was not found.
        echo Install Python 3.11 or newer, then run this file again.
        echo.
        pause
        exit /b 1
    )
)

echo Installing required packages...
%PY% -m pip install --upgrade pip
if errorlevel 1 goto :fail

%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Starting MouseFX...
%PY% mouse_fx_windows.py
if errorlevel 1 goto :fail

exit /b 0

:fail
echo.
echo Setup or launch failed.
pause
exit /b 1
