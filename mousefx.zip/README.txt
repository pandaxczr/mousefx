MouseFX for Windows

1. Extract this ZIP anywhere.
2. Double-click INSTALL_AND_RUN.bat.
3. It installs the required Python packages and starts MouseFX.

If Windows says Python is missing, install Python 3.11+ from python.org and run the BAT again.
