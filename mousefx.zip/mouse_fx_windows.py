import sys, math, time, json, os, ctypes
from collections import deque

from PySide6.QtCore import Qt, QTimer, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QLinearGradient
from PySide6.QtWidgets import QApplication, QWidget

FPS = 60
BASE_LIFETIME = 0.65
BASE_WIDTH = 4.5
TRAIL_SPACING = 3
MAX_POINTS = 110
BUCKETS = 14

SETTINGS_PATH = os.path.join(os.path.expanduser("~"), "MouseFX", "settings.json")

TRAIL_STYLES = [
    "Helix wave", "DNA", "Ribbon", "Neon", "Comet",
    "Lightning", "Fire", "Pixel", "Wake"
]
RUN_STYLES = ("Helix wave", "DNA", "Ribbon", "Neon", "Comet", "Lightning")
CLICK_STYLES = ["Ripple", "Double ring", "Burst", "Pulse in"]

# Windows DPI awareness: keep mouse coordinates and the overlay aligned.
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

def rgb_at(t):
    t = t % 1.0
    h = t * 6.0
    i = int(h)
    f = h - i
    q = 1.0 - f
    vals = ((1, f, 0), (q, 1, 0), (0, 1, f),
            (0, q, 1), (f, 0, 1), (1, 0, q))
    r, g, b = vals[i % 6]
    return QColor(int(r * 255), int(g * 255), int(b * 255))

def mix_white(c, a):
    return QColor(
        int(c.red() + (255 - c.red()) * a),
        int(c.green() + (255 - c.green()) * a),
        int(c.blue() + (255 - c.blue()) * a),
        c.alpha()
    )

class EffectOverlay(QWidget):
    def __init__(self, screen, app):
        super().__init__()
        self.app = app
        self.screen = screen
        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.Tool |
            Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setGeometry(screen.geometry())
        self.points = deque(maxlen=MAX_POINTS)
        self.clicks = []
        self.last_mouse = None
        self.last_time = time.perf_counter()

    def add_point(self, x, y, now):
        if self.last_mouse is not None:
            dx = x - self.last_mouse[0]
            dy = y - self.last_mouse[1]
            if dx * dx + dy * dy < TRAIL_SPACING * TRAIL_SPACING:
                return
        self.points.append((x, y, now))
        self.last_mouse = (x, y)

    def add_click(self, x, y, button, now):
        self.clicks.append([x, y, now, button])

    def prune(self, now):
        cutoff = now - BASE_LIFETIME
        while self.points and self.points[0][2] < cutoff:
            self.points.popleft()
        self.clicks[:] = [c for c in self.clicks if now - c[2] < 0.55]

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        now = time.perf_counter()
        self.prune(now)

        ox, oy = self.screen.geometry().x(), self.screen.geometry().y()
        pts = [(x - ox, y - oy, t) for x, y, t in self.points]

        if self.app.enabled and self.app.trail_style:
            self.draw_trail(p, pts, now)

        if self.app.click_style:
            self.draw_clicks(p, now, ox, oy)

    def draw_trail(self, p, pts, now):
        style = self.app.trail_style
        if len(pts) < 2:
            return

        if style == "Pixel":
            for i, (x, y, t) in enumerate(pts):
                age = now - t
                a = max(0.0, 1.0 - age / BASE_LIFETIME)
                if a <= 0:
                    continue
                s = max(1, int(BASE_WIDTH * (0.45 + a)))
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(255, 255, 255, int(230 * a)))
                p.drawRect(int(x - s/2), int(y - s/2), s, s)
            return

        # Keep the same general trail geometry: each point gets a rainbow
        # colour and an age-based alpha/width.
        for i in range(1, len(pts)):
            x0, y0, t0 = pts[i-1]
            x1, y1, t1 = pts[i]
            age = now - t1
            a = max(0.0, 1.0 - age / BASE_LIFETIME)
            if a <= 0:
                continue

            dx, dy = x1 - x0, y1 - y0
            length = math.hypot(dx, dy) or 1.0
            nx, ny = -dy / length, dx / length

            phase = (i / max(1, len(pts) - 1))
            wave = math.sin(i * 0.55 + now * 7.0) * 2.0

            if style == "Helix wave":
                ax, ay = nx * wave, ny * wave
                c = rgb_at(phase + now * 0.10)
                self.segment(p, x0 + ax, y0 + ay, x1 + ax, y1 + ay,
                             c, a, BASE_WIDTH)

            elif style == "DNA":
                c = rgb_at(phase + now * 0.08)
                w = math.sin(i * 0.65 + now * 8.0) * 4.0
                self.segment(p, x0 + nx*w, y0 + ny*w,
                             x1 + nx*w, y1 + ny*w, c, a, BASE_WIDTH * .8)
                c2 = rgb_at(phase + 0.5 + now * 0.08)
                self.segment(p, x0 - nx*w, y0 - ny*w,
                             x1 - nx*w, y1 - ny*w, c2, a, BASE_WIDTH * .8)

            elif style == "Ribbon":
                c = rgb_at(phase + now * 0.07)
                self.segment(p, x0 + nx*3, y0 + ny*3,
                             x1 + nx*3, y1 + ny*3, c, a, BASE_WIDTH * 1.35)
                self.segment(p, x0 - nx*3, y0 - ny*3,
                             x1 - nx*3, y1 - ny*3, mix_white(c, .25),
                             a*.75, BASE_WIDTH * 1.35)

            elif style == "Neon":
                c = rgb_at(phase + now * 0.12)
                self.segment(p, x0, y0, x1, y1, mix_white(c, .1),
                             a*.25, BASE_WIDTH * 4.0)
                self.segment(p, x0, y0, x1, y1, c, a, BASE_WIDTH)

            elif style == "Comet":
                c = rgb_at(phase + now * 0.1)
                self.segment(p, x0, y0, x1, y1, c, a*a,
                             BASE_WIDTH * (0.4 + a))

            elif style == "Lightning":
                c = QColor(210, 235, 255, int(255*a))
                jitter = math.sin(i * 9.1 + now * 14) * 2.2
                self.segment(p, x0 + nx*jitter, y0 + ny*jitter,
                             x1 + nx*jitter, y1 + ny*jitter, c, a,
                             BASE_WIDTH * .75)

            elif style == "Fire":
                c = QColor(255, int(70 + 150*a), int(20 + 50*a),
                           int(255*a))
                self.segment(p, x0, y0, x1, y1, c, a, BASE_WIDTH * (0.8+a))

            elif style == "Wake":
                c = rgb_at(phase + now * 0.06)
                self.segment(p, x0 + nx*7, y0 + ny*7,
                             x1 + nx*7, y1 + ny*7, c, a*.35, BASE_WIDTH)
                self.segment(p, x0, y0, x1, y1, c, a, BASE_WIDTH)

    def segment(self, p, x0, y0, x1, y1, c, alpha, width):
        c.setAlpha(max(0, min(255, int(255 * alpha))))
        pen = QPen(c)
        pen.setWidthF(width)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.drawLine(QPointF(x0, y0), QPointF(x1, y1))

    def draw_clicks(self, p, now, ox, oy):
        for x, y, t, button in self.clicks:
            age = now - t
            q = min(1.0, age / .55)
            a = 1.0 - q
            x -= ox
            y -= oy
            c = rgb_at((t * .25) % 1.0)
            pen = QPen(c)
            pen.setWidthF(2.0)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)

            if self.app.click_style == "Ripple":
                r = 8 + 34*q
                c.setAlpha(int(220*a))
                p.setPen(QPen(c, 2))
                p.drawEllipse(QPointF(x, y), r, r)

            elif self.app.click_style == "Double ring":
                r = 7 + 30*q
                c.setAlpha(int(220*a))
                p.setPen(QPen(c, 2))
                p.drawEllipse(QPointF(x, y), r, r)
                c2 = mix_white(c, .25)
                c2.setAlpha(int(160*a))
                p.setPen(QPen(c2, 2))
                p.drawEllipse(QPointF(x, y), r*.58, r*.58)

            elif self.app.click_style == "Burst":
                c.setAlpha(int(230*a))
                p.setPen(QPen(c, 2))
                for k in range(10):
                    ang = k * math.tau / 10
                    r1, r2 = 7 + 8*q, 7 + 25*q
                    p.drawLine(QPointF(x+math.cos(ang)*r1,
                                       y+math.sin(ang)*r1),
                               QPointF(x+math.cos(ang)*r2,
                                       y+math.sin(ang)*r2))

            elif self.app.click_style == "Pulse in":
                r = 30 * (1-q) + 2
                c.setAlpha(int(220*a))
                p.setPen(QPen(c, 2))
                p.drawEllipse(QPointF(x, y), r, r)

class MouseFX:
    def __init__(self):
        self.enabled = True
        self.trail_style = "Neon"
        self.click_style = "Ripple"
        self.overlays = []
        self.last_buttons = 0
        self.points = []
        self.clicks = []
        self.last_pos = None
        self.last_add = 0.0

        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        self.load_settings()

        self.app = QApplication.instance()
        self.make_overlays()

        self.timer = QTimer()
        self.timer.timeout.connect(self.tick)
        self.timer.start(round(1000 / FPS))

    def load_settings(self):
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                s = json.load(f)
            self.enabled = bool(s.get("enabled", True))
            self.trail_style = s.get("trail_style", "Neon")
            self.click_style = s.get("click_style", "Ripple")
            if self.trail_style not in TRAIL_STYLES:
                self.trail_style = "Neon"
            if self.click_style not in CLICK_STYLES:
                self.click_style = "Ripple"
        except Exception:
            pass

    def save_settings(self):
        try:
            with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                json.dump({
                    "enabled": self.enabled,
                    "trail_style": self.trail_style,
                    "click_style": self.click_style,
                }, f, indent=2)
        except Exception:
            pass

    def make_overlays(self):
        for screen in self.app.screens():
            w = EffectOverlay(screen, self)
            w.show()
            self.overlays.append(w)

    def mouse_pos(self):
        pos = self.app.primaryScreen().availableGeometry().center()
        try:
            from PySide6.QtGui import QCursor
            p = QCursor.pos()
            return p.x(), p.y()
        except Exception:
            return pos.x(), pos.y()

    def tick(self):
        now = time.perf_counter()
        x, y = self.mouse_pos()

        if self.enabled:
            if self.last_pos is None:
                self.last_pos = (x, y)
            dx = x - self.last_pos[0]
            dy = y - self.last_pos[1]
            if dx*dx + dy*dy >= TRAIL_SPACING * TRAIL_SPACING:
                self.points.append((x, y, now))
                self.last_pos = (x, y)

        try:
            buttons = ctypes.windll.user32.GetKeyState(0x01) & 0x8000
            buttons |= (ctypes.windll.user32.GetKeyState(0x02) & 0x8000) >> 15
            # We only need a rising edge for primary/secondary click effects.
            mask = 0
            if ctypes.windll.user32.GetKeyState(0x01) & 0x8000:
                mask |= 1
            if ctypes.windll.user32.GetKeyState(0x02) & 0x8000:
                mask |= 2
            if mask & ~self.last_buttons:
                self.clicks.append([x, y, now, mask])
            self.last_buttons = mask
        except Exception:
            pass

        cutoff = now - BASE_LIFETIME
        while self.points and self.points[0][2] < cutoff:
            self.points.pop(0)
        self.clicks[:] = [c for c in self.clicks if now - c[2] < .55]

        for w in self.overlays:
            w.points = deque(self.points, maxlen=MAX_POINTS)
            w.clicks = self.clicks
            w.update()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("MouseFX")
    fx = MouseFX()
    sys.exit(app.exec())
