@echo off
setlocal
echo This removes the MouseFX virtual environment only if one exists.
if exist "%~dp0.venv" rmdir /s /q "%~dp0.venv"
echo Done.
pause
